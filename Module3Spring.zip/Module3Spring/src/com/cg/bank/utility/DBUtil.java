package com.cg.bank.utility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

//This is a Utility class which will be used for making connection with the Oracle Database
public class DBUtil {
	public static Connection conn=null;
	public static Connection createConnection() throws SQLException{
		try{
			InitialContext context =new InitialContext();
			
			//Here we are including the DataSource present in the
			//WildFly server to communicate with the Database
			DataSource ds=(DataSource)context.lookup("java:/jdbc/OracleDS");
			conn=ds.getConnection();		
		}catch (NamingException ne){
			ne.printStackTrace();
		}catch (SQLException se){
			se.printStackTrace();
		}
		return conn;
	}
	
	public static void closeConnection() throws SQLException{
		if(conn!=null)
			conn.close();
	}
}
