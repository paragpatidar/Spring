package com.cg.bank.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bank.dto.AccountBean;
import com.cg.bank.dto.TransactionBean;
import com.cg.bank.exception.BankException;

public interface Service {
	public List<AccountBean> validate(String cName) throws BankException;
	public void debit(TransactionBean trans) throws BankException;
}
