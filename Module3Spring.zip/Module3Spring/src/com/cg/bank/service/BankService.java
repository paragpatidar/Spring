package com.cg.bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.DAO;
import com.cg.bank.dto.AccountBean;
import com.cg.bank.dto.TransactionBean;
import com.cg.bank.exception.BankException;


public class BankService implements Service{
	//Instantiating the Bank DAO Class for database related operations
	ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
	DAO bankDAO = (BankDAO)appContext.getBean("bankDAO");

	/*@Autowired
	DAO bankDAO;*/
	
	//Calling DAO method to get the account details
	public List<AccountBean> validate(String cName) throws BankException{
		return bankDAO.validate(cName);
	}
	
	//Calling DAO method to insert the transaction details into database
	public void debit(TransactionBean trans) throws BankException{
		bankDAO.debit(trans);
	}
}
