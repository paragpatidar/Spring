package com.cg.bank.controller;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bank.dto.AccountBean;
import com.cg.bank.dto.TransactionBean;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;
import com.cg.bank.service.Service;

@Controller
public class TraineeController {
	private Service service=new BankService();
	
	@RequestMapping("/attender")
	public ModelAndView handleRequest(HttpServletRequest request,HttpServletResponse response) throws BankException {
	try{
	ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
	
	ModelAndView modelAndView = new ModelAndView("AccountInfo");
	
	String cName=request.getParameter("cName");
	List<AccountBean> acnts=service.validate(cName);
	modelAndView.addObject("Accounts",acnts);
	modelAndView.addObject("Name",cName);
	return modelAndView;
	}
	catch (BankException e) {
		ModelAndView modelAndView = new ModelAndView("CustomerError");
		modelAndView.addObject("Error", e.getMessage());
		return modelAndView;
		}
	}	
	
	@RequestMapping(value = "/Debit",method=RequestMethod.POST)
	public ModelAndView sayHello(@RequestParam(value="acNo", required=true) String acNo,@RequestParam(value="amount", required=true) int amt) {
		try {
			TransactionBean trans=new TransactionBean();
			trans.setAccountNo(acNo);
			trans.setTransAmt(amt);
			trans.setTransDesc("ATM Debit");
			trans.setTransDate(Date.valueOf(LocalDate.now()));
			service.debit(trans);
			ModelAndView modelAndView = new ModelAndView("TransactionSuccess");
			modelAndView.addObject("Amount", amt);
			modelAndView.addObject("AccountNo", acNo);
			return modelAndView;
			} catch (BankException e) {	
				ModelAndView modelAndView = new ModelAndView("CustomerError");
				modelAndView.addObject("Error", e.getMessage());
				return modelAndView;
			}
	}
}
