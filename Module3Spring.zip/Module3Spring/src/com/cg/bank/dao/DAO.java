package com.cg.bank.dao;

import java.util.List;

import com.cg.bank.dto.AccountBean;
import com.cg.bank.dto.TransactionBean;
import com.cg.bank.exception.BankException;

public interface DAO {
	//public int getId() throws BankException;
	public void debit(TransactionBean trans) throws BankException;
	public  List<AccountBean> validate(String cName) throws BankException;
	void beginTransaction();
	void commitTransaction();
}
